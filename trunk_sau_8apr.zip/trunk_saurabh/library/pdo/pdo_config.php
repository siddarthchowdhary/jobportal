<?
/* Example Config for MYSQL */
$config = array();
$config['user'] = 'root';
$config['pass'] = 'root';
$config['name'] = 'job_portal';
$config['host'] = 'localhost';
$config['type'] = 'mysql';
$config['port'] = null;
$config['persistent'] = true;




?>
