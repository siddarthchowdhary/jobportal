[SQL]
host = localhost
user = root
password = root
dbname = job_portal
