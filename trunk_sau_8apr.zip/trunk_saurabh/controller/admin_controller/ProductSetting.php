<?php
/* @author : Ashwani Singh
 * @date   : 21-03-13
 * @description : JobPortal Product Setting Controller
 * 
*/
class ProductSettingController
{
	public function display()
	{
		echo "Product setting display";
	}
}
?>
