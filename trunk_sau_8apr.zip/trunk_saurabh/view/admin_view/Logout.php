<?php
/* @author : Ashwani Singh
 * @date   : 30-03-13
 * @description : Admin Logout View
 * 
*/
require_once($_SERVER['DOCUMENT_ROOT'].'/jobportal/trunk/config/constants.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Logout Successful</title>
	<link href=<?php echo CSS_PATH.'loginModule.css';?> rel="stylesheet" type="text/css" />
</head>
<body>
	
	<p align="center"></p>
<h4 align="center" class="err">Logout successful!</h4>
  
  

  <h4 align="center" class="err"> <a href=<?php echo SITE_PATH.'indexMain.php';?> >Click Here To Go back to Home Page!</a</h4>
</body>
</html>
