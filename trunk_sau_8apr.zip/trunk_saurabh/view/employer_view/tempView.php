<?php
echo"<pre>";
print_r($arrData);
?>
